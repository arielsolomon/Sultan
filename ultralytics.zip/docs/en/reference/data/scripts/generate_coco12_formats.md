---
description: TODO ADD DESCRIPTION
keywords: TODO ADD KEYWORDS
---

# Reference for `ultralytics/data/scripts/generate_coco12_formats.py`

!!! success "Improvements"

    This page is sourced from [https://github.com/ultralytics/ultralytics/blob/main/ultralytics/data/scripts/generate_coco12_formats.py](https://github.com/ultralytics/ultralytics/blob/main/ultralytics/data/scripts/generate_coco12_formats.py). Have an improvement or example to add? Open a [Pull Request](https://docs.ultralytics.com/help/contributing/) — thank you! 🙏

<br>

## ::: ultralytics.data.scripts.generate_coco12_formats.write_mpo

<br><br><hr><br>

## ::: ultralytics.data.scripts.generate_coco12_formats.write_dng

<br><br><hr><br>

## ::: ultralytics.data.scripts.generate_coco12_formats.convert_image

<br><br><hr><br>

## ::: ultralytics.data.scripts.generate_coco12_formats.generate_coco12_formats

<br><br><hr><br>

## ::: ultralytics.data.scripts.generate_coco12_formats.find_label

<br><br>
